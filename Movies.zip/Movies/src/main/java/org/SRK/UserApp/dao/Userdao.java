package org.SRK.UserApp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.SRK.UserApp.dto.Movie;
import org.SRK.UserApp.dto.Movie;


public class Userdao {
	EntityManagerFactory f=Persistence.createEntityManagerFactory("dev");
	EntityManager m=f.createEntityManager();
	public Movie saveUser(Movie u) {
		EntityTransaction t=m.getTransaction();
		m.persist(u);
		t.begin();
		t.commit();
		return u;
	}
	public Movie UpdateUser(Movie u) {
		EntityTransaction t=m.getTransaction();
		m.merge(u);
		t.begin();
		t.commit();
		return u;
	}
	public List<Movie> fetchAll(){
		String qr="select u from User u";
		Query q=m.createQuery(qr);
		return q.getResultList();
	}
	public Movie findById(int id)
	{
//		Query qr=m.createQuery("select u from User u where u.id=?1 ");
//		q.setParameter(1, id);
		Movie u=m.find(Movie.class, id);	
			return u;
		
	}
	public boolean DeleteUser(int id)
	{
		EntityTransaction t=m.getTransaction();
		Movie u=m.find(Movie.class, id);
		if(u!=null)
		{
			m.remove(u);
			t.begin();
			t.commit();
			return true;
		}
		return false;
	}
}
