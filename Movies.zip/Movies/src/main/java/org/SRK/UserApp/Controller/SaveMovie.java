package org.SRK.UserApp.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.SRK.UserApp.dao.Userdao;
import org.SRK.UserApp.dto.Movie;

@WebServlet("/signup")
public class SaveMovie extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String mname=req.getParameter("nm");
		String mActor=req.getParameter("Ac");
		Movie u=new Movie();
		Userdao dao=new Userdao();
		u.setName(mname);
		u.setActor(mActor);
		u=dao.saveUser(u);
		PrintWriter writer=resp.getWriter();
		writer.write("<html><body><h1> data is inserted with id ="+u.getId()+"</h1></body></html>");
		RequestDispatcher dispatcher=req.getRequestDispatcher("Home.jsp");
		dispatcher.include(req, resp);
	}
}
