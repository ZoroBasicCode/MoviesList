package org.SRK.UserApp.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.SRK.UserApp.dao.Userdao;
import org.SRK.UserApp.dto.Movie;

@WebServlet("/edit")
public class Edit extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id=Integer.parseInt(req.getParameter("id"));
		String name=req.getParameter("nm");
		String Actor=req.getParameter("Ac");
		Userdao dao=new Userdao();
		Movie u=dao.findById(id);
		u.setName(name);
		u.setActor(Actor);
		u=dao.UpdateUser(u);
		RequestDispatcher dispatcher=null;
		PrintWriter writer=resp.getWriter();
		if(u!=null) {
			writer.write("<html><body><h1>got the data "+u.getId()+"name "+u.getName()+"</h1></body></html>");
			HttpSession session=req.getSession();
			session.setAttribute("User", u);
			dispatcher =req.getRequestDispatcher("getData.jsp");
			dispatcher.forward(req, resp);
		}
		else {
			dispatcher=req.getRequestDispatcher("add.jsp");
			dispatcher.include(req, resp);
		}
	}
}
